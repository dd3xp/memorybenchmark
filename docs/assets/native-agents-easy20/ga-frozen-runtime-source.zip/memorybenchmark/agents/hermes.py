"""Native Hermes lifecycle; curated memory and self-authored skills persist."""
from pathlib import Path
import shutil

from ..agent_adapters import AgentAdapter, PreparedAgent
from ..ga_runtime import extract_native


class HermesAdapter(AgentAdapter):
    agent_id = "hermes"
    label = "native_Hermes"
    prompt_protocol = "cartography-native-memory-3"
    task_anchor = "public_current_task_on_every_model_call"
    worker_protocol = "hermes-session-1"
    worker_filename = "hermes_worker.py"

    def prepare(self, archive, root):
        source = extract_native(archive, root / "source", native="hermes")
        baseline = root / "baseline"
        baseline.mkdir()
        # Native built-in curated stores start empty. Shipped skills remain in
        # the read-only source and are not fabricated game experience.
        (baseline / "memories").mkdir()
        (baseline / "skills").mkdir()
        support = root / "support"
        support.mkdir()
        for name in ("hermes_worker.py", "ga_worker.py", "agent_bridge.py"):
            shutil.copyfile(Path(__file__).parents[1] / name, support / name)
        return PreparedAgent(source, support, baseline)
